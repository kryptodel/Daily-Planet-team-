# 📰 Daily Planet — Site Oficial

Site profissional com **estilo HQ / Comic Book** para a equipe **Daily Planet**, desenvolvedora de bots Discord.

## 📁 Estrutura

```
daily-planet-site/
├── index.html              → Página inicial
├── css/style.css           → Estilos (tema HQ)
├── js/script.js            → Menu mobile
├── pages/
│   ├── equipe.html         → Página da equipe
│   ├── bots.html           → Lista de bots
│   ├── termos.html         → Termos de Uso
│   ├── privacidade.html    → Política de Privacidade
│   └── bots/
│       ├── guardian.html   → Página do bot Guardian
│       ├── arcade.html     → Página do bot Arcade
│       └── reporter.html   → Página do bot Reporter
└── README.md
```

## 🚀 Como usar

1. Abra o arquivo `index.html` no navegador (ou hospede em qualquer servidor estático: Vercel, Netlify, GitHub Pages, etc.).
2. **Personalize os links dos bots**:
   - Substitua `SEU_CLIENT_ID_GUARDIAN`, `SEU_CLIENT_ID_ARCADE` e `SEU_CLIENT_ID_REPORTER` pelos Client IDs reais dos seus bots (encontrados no [Discord Developer Portal](https://discord.com/developers/applications)).
3. **Troque o convite do Discord**:
   - Substitua `https://discord.gg/SEU_CONVITE` pelo link real do seu servidor de suporte.
4. **Edite nomes, descrições e membros da equipe** conforme a realidade.
5. **Adicione novos bots**:
   - Copie um card em `bots.html` e uma página em `pages/bots/`.
   - Atualize os links.

## 🎨 Estilo

- Tipografia: **Bangers** (títulos) + **Comic Neue**
- Cores: amarelo HQ, azul escuro, vermelho, creme
- Bordas grossas pretas, sombras deslocadas (efeito comic)
- Speech bubbles e painéis estilo revista em quadrinhos
- Totalmente responsivo

## 📌 Observações

- Site 100% estático (HTML + CSS + JS puro).
- Não precisa de backend.
- Pronto para hospedagem gratuita.

Feito com ❤️ pela vibe Daily Planet.
